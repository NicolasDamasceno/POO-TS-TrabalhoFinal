import { Personagem } from "./personagemBase";

enum TipoAcao {
    ATAQUE = "Ataque Físico",
    MAGIA = "Magia",
    CRITICO = "Ataque Crítico",
    ATAQUE_DUPLO = "Ataque Duplo",
    FALHA = "Falha",
    DEFESA = "Defesa",
    CURA = "Cura",
    AUTODANO = "AutoDano"
}

let _acaoIdCounter = 1;

class Acao {
    private _id: number;
    private _origem: Personagem;
    private _alvo: Personagem;
    private _descricao: string;
    private _tipo: TipoAcao;
    private _valorDano: number;
    private _dataHora: Date;

    constructor(origem: Personagem, alvo: Personagem, tipo: TipoAcao, valorDano: number, descricao?: string) {
        this._id = _acaoIdCounter++;
        this._origem = origem;
        this._alvo = alvo;
        this._tipo = tipo;
        this._valorDano = valorDano;

        if (descricao !== undefined && descricao !== null && descricao !== "") {
            this._descricao = descricao;
        } else {
            this._descricao = tipo;
        }

        this._dataHora = new Date();
    }

    get id(): number { return this._id; }
    get origem(): Personagem { return this._origem; }
    get alvo(): Personagem { return this._alvo; }
    get descricao(): string { return this._descricao; }
    get tipo(): TipoAcao { return this._tipo; }
    get valorDano(): number { return this._valorDano; }
    get dataHora(): Date { return this._dataHora; }

    toJSON() {
        return {
            id: this._id,
            origemId: this._origem.id,
            origemNome: this._origem.nome,
            alvoId: this._alvo.id,
            alvoNome: this._alvo.nome,
            descricao: this._descricao,
            tipo: this._tipo,
            valorDano: this._valorDano,
            dataHora: this._dataHora.toISOString()
        };
    }
}

export { Acao, TipoAcao };