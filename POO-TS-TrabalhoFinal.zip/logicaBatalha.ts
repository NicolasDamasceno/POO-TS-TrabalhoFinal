import { Personagem } from "./personagemBase";
import { Acao, TipoAcao } from "./acoes";
import { Guerreiro, Mago, Arqueiro } from "./subClasses";
import * as fs from "fs";

class Batalha {
    private _personagens: Personagem[] = [];
    private _acoes: Acao[] = [];
    private _estado: "INATIVA" | "ANDAMENTO" | "FINALIZADA" = "INATIVA";

    constructor() {
        this._personagens = [];
        this._acoes = [];
    }

    adicionarPersonagem(personagem: Personagem): void {
        if (this.consultarPersonagemByName(personagem.nome)) {
            throw new Error("Nome de personagem já existe!");
        }
        this._personagens.push(personagem);
    }

    consultarPersonagemById(id: number): Personagem | undefined {
        return this._personagens.find(p => p.id === id);
    }

    consultarPersonagemByName(nome: string): Personagem | undefined {
        return this._personagens.find(p => p.nome.toLowerCase() === nome.toLowerCase());
    }

    turno(atacanteId: number, defensorId: number): Acao[] {
        const atacante = this.consultarPersonagemById(atacanteId);
        const defensor = this.consultarPersonagemById(defensorId);

        if (!atacante) throw new Error("Atacante não encontrado");
        if (!defensor) throw new Error("Defensor não encontrado");
        if (!atacante.estaVivo()) throw new Error("Atacante está morto");
        if (!defensor.estaVivo()) throw new Error("Defensor já está morto");

        const acao = atacante.atacar(defensor);

        if (Array.isArray(acao)) {
            for (const a of acao) this._acoes.push(a);
            return acao;
        } else {
            this._acoes.push(acao);
            return [acao];
        }
    }

    listarPersonagens(): Personagem[] {
        return this._personagens;
    }

    listarAcoes(): Acao[] {
        return this._acoes;
    }

    verificarVencedor(): Personagem | undefined {
        const vivos = this._personagens.filter(p => p.estaVivo());
        if (vivos.length === 1) {
            this._estado = "FINALIZADA";
            return vivos[0];
        }
        return undefined;
    }

    listarVivos(): Personagem[] {
        return this._personagens.filter(p => p.estaVivo());
    }

    listarMortos(): Personagem[] {
        return this._personagens.filter(p => !p.estaVivo());
    }

    persistirPersonagens(caminho = "personagens.json") {
        const json = JSON.stringify(
            this._personagens.map(p => p.toJSON()),
            null,
            2
        );
        fs.writeFileSync(caminho, json, { encoding: "utf-8" });
    }

    carregarPersonagens(caminho = "personagens.json") {
        if (!fs.existsSync(caminho)) return;

        const raw = fs.readFileSync(caminho, { encoding: "utf-8" });
        const arr = JSON.parse(raw);
        this._personagens = [];

        for (const obj of arr) {
            const cls = obj.classe;

            if (cls === "Guerreiro") {
                const defesa = (obj.defesa !== undefined && obj.defesa !== null)
                    ? obj.defesa
                    : 10;

                this._personagens.push(
                    new Guerreiro(obj.id, obj.nome, obj.vida, obj.ataque, defesa)
                );
            }
            else if (cls === "Mago") {
                this._personagens.push(
                    new Mago(obj.id, obj.nome, obj.vida, obj.ataque)
                );
            }
            else if (cls === "Arqueiro") {
                const ataqueMultiplo = (obj.ataqueMultiplo !== undefined && obj.ataqueMultiplo !== null)
                    ? obj.ataqueMultiplo
                    : 3;

                this._personagens.push(
                    new Arqueiro(obj.id, obj.nome, obj.vida, obj.ataque, ataqueMultiplo)
                );
            }
            else {
                const p = new (require("./personagemBase").Personagem)(
                    obj.id,
                    obj.nome,
                    obj.vida,
                    obj.ataque
                );
                this._personagens.push(p);
            }
        }
    }

    persistirAcoes(caminho = "acoes.json") {
        const json = JSON.stringify(
            this._acoes.map(a =>
                a.toJSON ? a.toJSON() : a
            ),
            null,
            2
        );
        fs.writeFileSync(caminho, json, { encoding: "utf-8" });
    }
}

export { Batalha, Guerreiro, Mago, Arqueiro };