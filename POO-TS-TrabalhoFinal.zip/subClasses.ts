import { Personagem } from "./personagemBase";
import { Acao, TipoAcao } from "./acoes";

class Guerreiro extends Personagem {
    private _defesa: number;

    constructor(id: number, nome: string, vida: number, ataque: number, defesa: number) {
        super(id, nome, vida, ataque);
        if (typeof defesa !== "number" || defesa < 0) throw new Error("Defesa inválida");
        this._defesa = defesa;
    }

    get defesa(): number { return this._defesa; }

    atacar(alvo: Personagem): Acao {
        if (!this.estaVivo()) throw new Error(`${this.nome} está morto e não pode atacar!`);
        if (this === alvo) throw new Error("Personagem não pode atacar a si mesmo!");
        if (!alvo.estaVivo()) throw new Error("Alvo está morto e não pode ser atacado!");

        let danoBase = this.ataque;

        if (this.vida < (this.vidaMaxima * 0.3)) {
            danoBase = Math.floor(danoBase * 1.3); // +30%
        }

        let danofinal: number;
        if ((alvo as any) instanceof Guerreiro) {
            danofinal = Math.max(0, danoBase - (alvo as Guerreiro).defesa);
        } else {
            danofinal = Math.max(0, danoBase);
        }

        alvo.receberDano(danofinal);
        const acao = new Acao(this, alvo, TipoAcao.ATAQUE, danofinal, `${this.nome} ataca ${alvo.nome}`);
        this.registrarAcao(acao);
        alvo.registrarAcao(acao);
        return acao;
    }

    receberDano(valor: number): void {
        super.receberDano(valor);
    }
}

class Mago extends Personagem {
    constructor(id: number, nome: string, vida: number, ataque: number) {
        super(id, nome, vida, ataque);
    }

    magia(alvo: Personagem): Acao[] {
        if (!this.estaVivo()) throw new Error(`${this.nome} está morto e não pode lançar magias!`);
        if (this === alvo) throw new Error("Personagem não pode atacar a si mesmo!");
        if (!alvo.estaVivo()) throw new Error("Alvo está morto e não pode ser atacado!");
        if (this.vida <= 10) throw new Error(`${this.nome} não tem vida suficiente para realizar Magia!`);
        
        this.receberDano(10);
        const autoDanoAcao = new Acao(this, this, TipoAcao.AUTODANO, 10, `${this.nome} sofre custo de magia`);

        let danoMagia = 30;
        if ((alvo as any).constructor && (alvo as any).constructor.name === "Arqueiro") {
            danoMagia *= 2;
        }

        alvo.receberDano(danoMagia);
        const acaoMagia = new Acao(this, alvo, TipoAcao.MAGIA, danoMagia, `${this.nome} conjura magia em ${alvo.nome}`);
        this.registrarAcao(autoDanoAcao);
        this.registrarAcao(acaoMagia);
        alvo.registrarAcao(acaoMagia);
        return [acaoMagia, autoDanoAcao];
    }

    atacar(alvo: Personagem): Acao {
        if (!this.estaVivo()) throw new Error(`${this.nome} está morto e não pode atacar!`);
        if (this === alvo) throw new Error("Personagem não pode atacar a si mesmo!");
        if (!alvo.estaVivo()) throw new Error("Alvo está morto e não pode ser atacado!");

        let danofinal = Math.max(0, Math.floor((this.ataque * 0.6)));
        alvo.receberDano(danofinal);
        const acao = new Acao(this, alvo, TipoAcao.ATAQUE, danofinal, `${this.nome} ataca ${alvo.nome}`);
        this.registrarAcao(acao);
        alvo.registrarAcao(acao);
        return acao;
    }
}

class Arqueiro extends Personagem {
    private _ataqueMultiplo: number;

    constructor(id: number, nome: string, vida: number, ataque: number, ataqueMultiplo: number) {
        super(id, nome, vida, ataque);
        if (!Number.isInteger(ataqueMultiplo) || ataqueMultiplo < 1) throw new Error("ataqueMultiplo inválido");
        this._ataqueMultiplo = ataqueMultiplo;
    }

    atacar(alvo: Personagem): Acao {
        if (!this.estaVivo()) throw new Error(`${this.nome} está morto e não pode atacar!`);
        if (this === alvo) throw new Error("Personagem não pode atacar a si mesmo!");
        if (!alvo.estaVivo()) throw new Error("Alvo está morto e não pode ser atacado!");

        const multiplicador = (Math.random() < 0.5) ? this._ataqueMultiplo : 1;
        const dano = Math.max(0, this.ataque * multiplicador);
        alvo.receberDano(dano);
        const tipo = (multiplicador === 1) ? TipoAcao.ATAQUE : TipoAcao.ATAQUE_DUPLO;
        const acao = new Acao(this, alvo, tipo, dano, `${this.nome} atira em ${alvo.nome} (x${multiplicador})`);
        this.registrarAcao(acao);
        alvo.registrarAcao(acao);
        return acao;
    }
}

export { Guerreiro, Mago, Arqueiro };