import * as readline from "readline";
import { Batalha } from "./logicaBatalha";
import { Guerreiro, Mago, Arqueiro } from "./logicaBatalha";

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function pergunta(prompt: string): Promise<string> {
    return new Promise(resolve => rl.question(prompt, ans => resolve(ans)));
}

async function menu() {
    const batalha = new Batalha();

    console.log("Carregando personagens salvos (se existirem)...");
    batalha.carregarPersonagens();

    console.log("=== Sistema de Batalha ===");
    let sair = false;
    while (!sair) {
        console.log("\nOpções:");
        console.log("1) Listar personagens");
        console.log("2) Adicionar Guerreiro");
        console.log("3) Adicionar Mago");
        console.log("4) Adicionar Arqueiro");
        console.log("5) Simular turno (manual)");
        console.log("6) Exemplo de batalha (do enunciado)");
        console.log("7) Salvar personagens");
        console.log("8) Listar ações");
        console.log("9) Sair");
        const opc = await pergunta("Escolha opção: ");

        try {
            switch (opc.trim()) {
                case "1":
                    const ps = batalha.listarPersonagens();
                    if (ps.length === 0) console.log("Nenhum personagem cadastrado.");
                    else {
                        console.log("Personagens:");
                        for (const p of ps) {
                            console.log(`ID: ${p.id} | Nome: ${p.nome} | Vida: ${p.vida}/${p.vidaMaxima} | Classe: ${p.constructor.name}`);
                        }
                    }
                    break;
                case "2": {
                    const id = parseInt(await pergunta("Id (número): "));
                    const nome = await pergunta("Nome: ");
                    const vida = parseInt(await pergunta("Vida (0-100): "));
                    const ataque = parseInt(await pergunta("Ataque: "));
                    const defesa = parseInt(await pergunta("Defesa: "));
                    batalha.adicionarPersonagem(new Guerreiro(id, nome, vida, ataque, defesa));
                    console.log("Guerreiro adicionado.");
                    break;
                }
                case "3": {
                    const id = parseInt(await pergunta("Id (número): "));
                    const nome = await pergunta("Nome: ");
                    const vida = parseInt(await pergunta("Vida (0-100): "));
                    const ataque = parseInt(await pergunta("Ataque: "));
                    batalha.adicionarPersonagem(new Mago(id, nome, vida, ataque));
                    console.log("Mago adicionado.");
                    break;
                }
                case "4": {
                    const id = parseInt(await pergunta("Id (número): "));
                    const nome = await pergunta("Nome: ");
                    const vida = parseInt(await pergunta("Vida (0-100): "));
                    const ataque = parseInt(await pergunta("Ataque: "));
                    const atkMult = parseInt(await pergunta("AtaqueMultiplo (ex: 3): "));
                    batalha.adicionarPersonagem(new Arqueiro(id, nome, vida, ataque, atkMult));
                    console.log("Arqueiro adicionado.");
                    break;
                }
                case "5": {
                    const idA = parseInt(await pergunta("Id do atacante: "));
                    const idD = parseInt(await pergunta("Id do defensor: "));
                    const atac = batalha.listarPersonagens().find(p => p.id === idA);
                    if (!atac) throw new Error("Atacante não encontrado");
                    if (attEhMago(atac) && (await pergunta("Usar magia? (s/n): ")).toLowerCase().startsWith("s")) {
                        const mago = atac as any;
                        const alvo = batalha.listarPersonagens().find(p => p.id === idD);
                        const acoes = mago.magia(alvo);
                        acoes.forEach((a: any) => (batalha as any).listarAcoes().push(a));
                        console.log("Magia executada.");
                    } else {
                        const res = (batalha as any).turno(idA, idD);
                        console.log("Turno processado. Ação(s):");
                        for (const a of res) {
                            console.log(`${a.origem.nome} -> ${a.alvo.nome} : ${a.tipo} = ${a.valorDano}`);
                        }
                    }
                    const vencedor = batalha.verificarVencedor();
                    if (vencedor) console.log(`Vencedor: ${vencedor.nome} (${vencedor.constructor.name})`);
                    break;
                }
                case "6": {
                    console.log("Executando exemplo de batalha do enunciado...");
                    executarExemplo();
                    break;
                }
                case "7":
                    batalha.persistirPersonagens();
                    batalha.persistirAcoes();
                    console.log("Dados salvos em arquivos JSON.");
                    break;
                case "8":
                    const acoes = batalha.listarAcoes();
                    if (acoes.length === 0) console.log("Nenhuma ação registrada.");
                    else {
                        for (const a of acoes) {
                            console.log(`${a.id} | ${a.dataHora.toISOString()} | ${a.origem.nome} -> ${a.alvo.nome} | ${a.tipo} | ${a.valorDano} | ${a.descricao}`);
                        }
                    }
                    break;
                case "9":
                    sair = true;
                    break;
                default:
                    console.log("Opção inválida.");
            }
        } catch (err: any) {
            console.log("Erro: " + err.message);
        }
    }

    rl.close();
    console.log("Encerrado.");
}

function attEhMago(p: any): boolean {
    return p && p.constructor && p.constructor.name === "Mago";
}

function executarExemplo() {
    const batalha = new Batalha();
    const thorgal = new (require("./subClasses").Guerreiro)(1, "Thorgal", 100, 25, 15);
    const lyra = new (require("./subClasses").Mago)(2, "Lyra", 100, 30);
    const elandor = new (require("./subClasses").Arqueiro)(3, "Elandor", 100, 15, 3);

    batalha.adicionarPersonagem(thorgal);
    batalha.adicionarPersonagem(lyra);
    batalha.adicionarPersonagem(elandor);

    const logs: any[] = [];

    const a1 = lyra.magia(thorgal); 
    
    (batalha as any).listarAcoes().push(...a1);
    logs.push(a1[0]);

    logs.push(a1[1]);
 
    const a3 = thorgal.atacar(elandor);
    (batalha as any).listarAcoes().push(a3);
    logs.push(a3);

    const a4 = elandor.atacar(lyra);
    (batalha as any).listarAcoes().push(a4);
    logs.push(a4);

    const a5a6 = lyra.magia(thorgal);
    (batalha as any).listarAcoes().push(...a5a6);
    logs.push(a5a6[0], a5a6[1]);

    const a7 = thorgal.atacar(elandor);
    (batalha as any).listarAcoes().push(a7);
    logs.push(a7);

    const a8 = elandor.atacar(lyra);
    (batalha as any).listarAcoes().push(a8);
    logs.push(a8);
 
    const a9a10 = lyra.magia(thorgal);
    (batalha as any).listarAcoes().push(...a9a10);
    logs.push(a9a10[0], a9a10[1]);

    const a11 = thorgal.atacar(elandor);
    (batalha as any).listarAcoes().push(a11);
    logs.push(a11);
   
    const dano12 = elandor.ataque * 3;
    elandor as any; 
    elandor.receberDano(0);
    const acao12 = new (require("./acoes").Acao)(elandor, lyra, (require("./acoes").TipoAcao).ATAQUE_DUPLO, dano12, `${elandor.nome} realiza ataque múltiplo em ${lyra.nome}`);
    (batalha as any).listarAcoes().push(acao12);
    lyra.receberDano(dano12);
    logs.push(acao12);

    const a13 = thorgal.atacar(elandor);
    (batalha as any).listarAcoes().push(a13);
    logs.push(a13);

    console.log("\n--- Extrato da Batalha (Exemplo) ---\n");
    for (let i = 0; i < logs.length; i++) {
        const ac = logs[i];
        console.log(`Ação ${i + 1}: ${ac.descricao} | Dano: ${ac.valorDano}`);
        console.log(`Status: Thorgal: ${(thorgal.vida)} vida | Lyra: ${(lyra.vida)} vida | Elandor: ${(elandor.vida)} vida\n`);
    }

    const vencedor = batalha.verificarVencedor();
    if (vencedor) {
        console.log(`Vencedor: ${vencedor.nome} - ${vencedor.constructor.name} com ${vencedor.vida} de vida.`);
    } else {
        console.log("Nenhum vencedor ainda (ou ambos morreram).");
    }
}

menu();