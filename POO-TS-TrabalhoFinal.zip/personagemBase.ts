import { Acao, TipoAcao } from "./acoes";

class Personagem {
    protected _id: number;
    protected _nome: string;
    protected _vida: number;
    protected _vidaMaxima: number;
    protected _ataque: number;
    protected _historico: Acao[] = [];

    constructor(id: number, nome: string, vida: number, ataque: number) {
        if (!Number.isInteger(id) || id < 0) throw new Error("Id inválido");
        if (!nome || nome.trim().length === 0) throw new Error("Nome inválido");
        if (typeof vida !== "number" || vida < 0 || vida > 100) throw new Error("Vida deve ser número entre 0 e 100");
        if (typeof ataque !== "number" || ataque < 0) throw new Error("Ataque inválido");

        this._id = id;
        this._nome = nome;
        this._vida = Math.floor(vida);
        this._vidaMaxima = Math.floor(vida);
        this._ataque = ataque;
    }

    get id(): number { return this._id; }
    get nome(): string { return this._nome; }
    get vida(): number { return this._vida; }
    get vidaMaxima(): number { return this._vidaMaxima; }
    get ataque(): number { return this._ataque; }

    estaVivo(): boolean { return this._vida > 0; }

    atacar(alvo: Personagem): Acao {
        if (!this.estaVivo()) {
            throw new Error(`${this.nome} está morto e não pode atacar!`);
        }
        if (!alvo) throw new Error("Alvo inválido");
        if (!alvo.estaVivo()) {
            throw new Error("Alvo está morto e não pode ser atacado!");
        }
        if (this === alvo) {
            throw new Error("Personagem não pode atacar a si mesmo!");
        }

        const dano = Math.max(0, this._ataque);
        const acao = new (require("./acoes").Acao)(this, alvo, TipoAcao.ATAQUE, dano, `${this.nome} ataca ${alvo.nome}`);
        this.registrarAcao(acao);
        alvo.registrarAcao(acao);
        alvo.receberDano(dano);
        return acao;
    }

    receberDano(valor: number): void {
        if (typeof valor !== "number" || isNaN(valor)) throw new Error("Valor de dano inválido");
        this._vida -= Math.floor(valor);
        if (this._vida < 0) this._vida = 0;
    }

    registrarAcao(acao: Acao): void {
        this._historico.push(acao);
    }

    recuperarHistorico(): Acao[] {
        return this._historico;
    }

    toJSON() {
        return {
            id: this._id,
            nome: this._nome,
            vida: this._vida,
            vidaMaxima: this._vidaMaxima,
            ataque: this._ataque,
            classe: (this.constructor && this.constructor.name) || "Personagem"
        };
    }
}

export { Personagem };